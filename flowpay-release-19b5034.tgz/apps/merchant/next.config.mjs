import path from "node:path";
import nextEnv from "@next/env";

const { loadEnvConfig } = nextEnv;

const projectRoot = path.resolve(process.cwd(), "../..");
loadEnvConfig(projectRoot);

/** @type {import("next").NextConfig} */
const nextConfig = {
  distDir: process.env.FLOWPAY_NEXT_DIST_DIR || ".next",
  outputFileTracingRoot: process.env.VERCEL ? process.cwd() : projectRoot,
  async rewrites() {
    const checkoutBase=(process.env.FLOWPAY_CHECKOUT_BASE_URL||"http://localhost:3001").replace(/\/$/,"");
    return [
      {source:"/pay/:path*",destination:`${checkoutBase}/pay/:path*`},
      {source:"/claim",destination:`${checkoutBase}/claim`},
      {source:"/claim/:path*",destination:`${checkoutBase}/claim/:path*`},
      {source:"/api/payment/:path*",destination:`${checkoutBase}/api/payment/:path*`},
      {source:"/api/claims/:path*",destination:`${checkoutBase}/api/claims/:path*`},
      {source:"/assets/glossy-neon-robot-assistant-icon.png",destination:`${checkoutBase}/assets/glossy-neon-robot-assistant-icon.png`},
      {source:"/assets/recovery-bot.svg",destination:`${checkoutBase}/assets/recovery-bot.svg`},
    ];
  },
};

export default nextConfig;
